<?php
$string['neesreqbtn'] = 'NEES Requisition Button';
$string['modulename'] = 'NEES Req Btn';
$string['modulenameplural'] = 'NEES Req Btns';
$string['buttontext'] = 'Button Text';

?>