<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_neesreqbtn';
$plugin->version = 2024100702;
$plugin->requires = 2020061500; // Versão mínima do Moodle (3.9 ou superior).
$plugin->maturity = MATURITY_STABLE;
$plugin->release = 'v1.2';

?>