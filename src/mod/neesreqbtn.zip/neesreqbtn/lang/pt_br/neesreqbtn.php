<?php
$string['neesreqbtn'] = 'Botão de Requisição NEES';
$string['modulename'] = 'Botão de Requisição NEES';
$string['modulenameplural'] = 'Botões de Requisição NEES';
$string['buttontext'] = 'Texto do Botão';
$string['buttonurl'] = 'URL do Botão';  // Novo campo
?>