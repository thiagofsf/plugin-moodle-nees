<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Adiciona uma nova instância da atividade.
 *
 * @param object $neesreqbtn Dados do formulário.
 * @return int ID da nova instância.
 */
function neesreqbtn_add_instance($neesreqbtn) {
    global $DB;
    $neesreqbtn->timemodified = time();
    return $DB->insert_record('neesreqbtn', $neesreqbtn);
}

/**
 * Atualiza uma instância existente da atividade.
 *
 * @param object $neesreqbtn Dados do formulário.
 * @return bool Sucesso ou falha.
 */
function neesreqbtn_update_instance($neesreqbtn) {
    global $DB;
    $neesreqbtn->timemodified = time();
    $neesreqbtn->id = $neesreqbtn->instance;
    return $DB->update_record('neesreqbtn', $neesreqbtn);
}

/**
 * Deleta uma instância da atividade.
 *
 * @param int $id ID da instância a ser deletada.
 * @return bool Sucesso ou falha.
 */
function neesreqbtn_delete_instance($id) {
    global $DB;
    if (!$neesreqbtn = $DB->get_record('neesreqbtn', ['id' => $id])) {
        return false;
    }
    return $DB->delete_records('neesreqbtn', ['id' => $id]);
}
